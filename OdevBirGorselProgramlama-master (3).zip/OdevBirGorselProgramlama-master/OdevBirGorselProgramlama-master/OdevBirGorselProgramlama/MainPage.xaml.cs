﻿using OdevBirGorselProgramlama.Views;

namespace OdevBirGorselProgramlama
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            var layout = new StackLayout();

            #region Main Page
           
                var image = new Image
                {
                    Source = "image.jpg",
                    WidthRequest = 200,
                    HeightRequest = 300,
                    Margin = 50 ,
                    
                    Aspect = Aspect.AspectFill,
                };

           
                layout.Children.Add(image);



            var nameLabel = new Label
            {
                Text = "Muhammed numan göktürk 20010310071",
                FontSize = 32,
                TextColor = Colors.Orange,
                Margin = 10 ,
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center
            };
            layout.Children.Add(nameLabel);

            var universityLabel = new Label
            {
                Text = "Bartın Üniversitesi",
                FontSize = 32,
                TextColor = Colors.OrangeRed,
                Margin = 10,
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center
            };
            layout.Children.Add(universityLabel);
            var bolumLabel = new Label
            {
                Text = "Bilgisayar Mühendisliği",
                FontSize = 26,
                TextColor = Colors.OrangeRed,
                Margin = 4,
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center
            };
            layout.Children.Add(bolumLabel);

            var assignmentLabel = new Label
            {
                Text = "Ödev",
                FontSize = 40,
                TextColor = Colors.Orange,
                Margin = 10,
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center
            };
            layout.Children.Add(assignmentLabel);

            Content = new ScrollView
            {
                Content = layout,
            };
            #endregion

            #region Menus
            var pageMainMenuItem = new ToolbarItem
            {
                //Text = "Ana Sayfa",
                IconImageSource= ImageSource.FromFile("home.png"),
                Order = ToolbarItemOrder.Primary,
                Priority = 0
            };

            pageMainMenuItem.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new MainPage());
            };

            ToolbarItems.Add(pageMainMenuItem);

            var pageBodyIndexMenuItem = new ToolbarItem
            {
                //Text = "Vücud İndeksi Hesaplama",
                IconImageSource = ImageSource.FromFile("body.png"),
                Order = ToolbarItemOrder.Primary,
               
                Priority = 1
            };

            pageBodyIndexMenuItem.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new BodyIndex());
            };

            ToolbarItems.Add(pageBodyIndexMenuItem);

            var pageColorPickerMenuItem = new ToolbarItem
            {
                //Text = "Renk Oluşturma",
                IconImageSource = ImageSource.FromFile("color.png"),
                Order = ToolbarItemOrder.Primary,
                Priority = 1
            };

            pageColorPickerMenuItem.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new ColorPicker());
            };

            ToolbarItems.Add(pageColorPickerMenuItem);

            var pageLoanMenuItem = new ToolbarItem
            {
                // Text = "Kredi Hesaplama",
                IconImageSource = ImageSource.FromFile("credit.png"),
                Order = ToolbarItemOrder.Primary,
                Priority = 1
            };

            pageLoanMenuItem.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new Loan());
            };

            ToolbarItems.Add(pageLoanMenuItem);

            var pageTodoMenuItem = new ToolbarItem
            {
               // Text = "Yapılacaklar Listesi",
                IconImageSource = ImageSource.FromFile("todo.png"),
                Order = ToolbarItemOrder.Primary,
                Priority = 1
            };

            pageTodoMenuItem.Clicked += async (sender, e) =>
            {
                await Navigation.PushAsync(new Todo());
            };

            ToolbarItems.Add(pageTodoMenuItem);
            #endregion
        }
    }

}
