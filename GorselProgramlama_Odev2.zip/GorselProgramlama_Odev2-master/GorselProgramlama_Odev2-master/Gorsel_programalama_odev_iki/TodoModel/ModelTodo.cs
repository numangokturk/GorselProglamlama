﻿using Google.Protobuf.WellKnownTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gorsel_programalama_odev_iki.TodoModel
{
    class ModelTodo
    {
        public string detay { get; set; }
        public string gorev { get; set; }
        public string zaman { get; set; }
    }
}
