﻿namespace Gorsel_programalama_odev_iki
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
