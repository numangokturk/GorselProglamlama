﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gorsel_programalama_odev_iki.RateModel
{
    public class RateItem
    {
        public string Buying { get; set; }
        public string Sales { get; set; }

        public string Change { get; set; }
      
        public string Yon { get; set; }
    }
}
