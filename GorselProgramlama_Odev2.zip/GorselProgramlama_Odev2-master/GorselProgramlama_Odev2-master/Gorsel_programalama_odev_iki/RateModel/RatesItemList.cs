﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gorsel_programalama_odev_iki.RateModel
{
    public  class RatesItemList
    {
       public string Name { get; set; }
        public string Satis {  get; set; }
        public string Alis { get; set; }

        public string Degisim { get; set; }
        public string DOran { get; set; }
        public string DYon { get; set; }



    }
}
